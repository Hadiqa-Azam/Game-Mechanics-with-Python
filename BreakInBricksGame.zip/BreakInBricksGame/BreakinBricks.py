import pygame
from pygame.locals import *
pygame.init()
screen = pygame.display.set_mode((800,600))
pygame.display.set_caption("Breakin' Briks")

#load images
bat = pygame.image.load('./images/paddle.png')
bat = bat.convert_alpha() # images comes with different pixels and this alpha aligns images with screen
bat_rect = bat.get_rect() #it determins where the bat is in our screen
bat_rect[1] = screen.get_height() - 100
#ball
ball = pygame.image.load('./images/football.png')
ball = ball.convert_alpha()
ball_rect = ball.get_rect()
ball_start = (210,210)
ball_speed = (3.0,3.0)
ball_served = False #statics the ball untill we want to move it
sx, sy =ball_speed
ball_rect.topleft = ball_start

#brick
brick = pygame.image.load('./images/brick.png')
brick = brick.convert_alpha()
brick_rect = brick.get_rect()

#placing bricks
bricks = []
brick_gap = 10
brick_rows = 5
brick_cols = screen.get_width() // (brick_rect[2] + brick_gap)
side_gap = (screen.get_width() - (brick_rect[2]+ brick_gap) * brick_cols + brick_gap) // 2
clock = pygame.time.Clock()
for y in range(brick_rows):
    dt = clock.tick(100)
    brickY = y * (brick_rect[3] + brick_gap) # as rect(screen x position,screen y position, width,height)
    for x in range(brick_cols):
        brickX = x * (brick_rect[2] + brick_gap) + side_gap
        bricks.append((brickX,brickY))


clock = pygame.time.Clock()
game_over = False

while not game_over:
    dt = clock.tick(50)
    screen.fill((0,0,0))

    for b in bricks:
        screen.blit(brick,b)
    screen.blit(bat, bat_rect)
    screen.blit(ball,ball_rect)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        pressed = pygame.key.get_pressed()
    if pressed[K_LEFT]:
        bat_rect[0] -= 0.5 * dt
    if pressed[K_RIGHT]:
        bat_rect[0] += 0.5 * dt
    if bat_rect[0] > (screen.get_width() - bat_rect[2]):
        bat_rect[0] = screen.get_width() - bat_rect[2]
    if bat_rect[0] < 0:
        bat_rect[0] = 0
    if pressed[K_SPACE]:
        ball_served = True

    if bat_rect[0] + bat_rect[2] >= ball_rect[0] >= bat_rect[0] and \
       ball_rect[1] + ball_rect[3] >= bat_rect[1] and sy >0:
        sy *= -1
        sx *= 1.02 #increase difficulty
        sy *= 1.02
        continue

    #delet Bricks
    delete_brick = None
    for b in bricks:
        bx,by = b
        if bx <= ball_rect[0] <= bx + brick_rect[2] and \
           by <= ball_rect[1] <= by + brick_rect[3]:
            delete_brick = b
            if ball_rect[0] <= bx +2:
                sx *= -1
            elif ball_rect[0] >= bx + brick_rect[2] -2:
                sx *= -1
            if ball_rect[1] <= by + 2:
                sy *= -1
            elif ball_rect[1] >= by + brick_rect[3] -2:
                sy *= -1
    if delete_brick is not None:
        bricks.remove(delete_brick)

    #ball Boundries
    # bottom
    if ball_rect[1] >= screen.get_height() - ball_rect.height:
        #ball_rect[1] = screen.get_height() - ball_rect.height
        #sy *= -1
        ball_served = False
        ball_rect.topleft = ball_start


    # left
    if ball_rect[0] <= 0:
        ball_rect[0] = 0
        sx *= -1
    #Right
    if ball_rect[0] >= screen.get_width() - ball_rect.width:
        ball_rect[0] = screen.get_width() - ball_rect.width
        sx *= -1
    #top
    if ball_rect[1] <= 0:
        ball_rect[1] = 0
        sy *= -1

    if ball_served:
        ball_rect[0] += sx
        ball_rect[1] += sy
    pygame.display.update()
pygame.quit()

